from django.apps import AppConfig


class GtinConfig(AppConfig):
    name = 'gtin'
